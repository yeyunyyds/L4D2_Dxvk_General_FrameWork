Development evidence only. The custom runtime may require additional DLLs and USD files from the CI artifact.
No L4D2 Source hook or combined test package A is included. GPU execution remains unrun.
