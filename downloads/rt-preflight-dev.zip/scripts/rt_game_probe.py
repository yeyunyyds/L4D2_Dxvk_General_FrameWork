"""Read-only loaded-module evidence for future L4D2 RT binding.

This collector never injects code, calls a game interface, installs a hook or
changes a CVar. A unique byte pattern or RTTI vtable is only a candidate.
"""

import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parents[1]
MODULES = {'CLIENT_MOD': 'client.dll', 'ENGINE_MOD': 'engine.dll',
           'RENDERER_MOD': 'shaderapidx9.dll'}
RENDERERS = ('shaderapidx9.dll', 'shaderapivk.dll')
CLASSES = {'CMaterialSystem': [95, 96], 'CMatRenderContext': list(range(256)),
           'CMatQueuedRenderContext': list(range(256))}
EXECUTE = 0x20000000
READ = 0x40000000
MAX_IMAGE = 256 * 1024 * 1024
MAX_SECTION = 64 * 1024 * 1024


def unique_modules(entries):
    """Coalesce identical Toolhelp aliases; preserve actual conflicting loads."""
    result = {}
    for entry in entries:
        key = (entry['name'].casefold(), entry['path'].casefold(), entry['base'], entry['size'])
        if key in result:
            result[key]['snapshot_alias_count'] += 1
        else:
            result[key] = {**entry, 'snapshot_alias_count': 1}
    return list(result.values())


def select_renderer(modules):
    """Select a loaded renderer, without treating matching patterns as an ABI."""
    loaded = [m for m in modules if m['name'] in RENDERERS]
    return {'result': 'unique_candidate' if len(loaded) == 1 else 'ambiguous' if loaded else 'unavailable',
            'name': loaded[0]['name'] if len(loaded) == 1 else None,
            'loaded': [{'name': m['name'], 'path': m['path'], 'base': m['base']} for m in loaded],
            'reference_module': MODULES['RENDERER_MOD'], 'interface_binding_verified': False}


def u32(data, offset=0):
    return struct.unpack_from('<I', data, offset)[0]


def pattern_bytes(pattern):
    tokens = pattern.split()
    if not tokens or len(tokens) > 512:
        raise ValueError('Invalid pattern length')
    values = []
    for token in tokens:
        if token in ('?', '??'):
            values.append(None)
        elif len(token) == 2 and all(c in '0123456789abcdefABCDEF' for c in token):
            values.append(int(token, 16))
        else:
            raise ValueError('Invalid pattern token')
    if all(x is None for x in values):
        raise ValueError('Pattern needs a fixed byte')
    return values


def matches(data, pattern, limit=4096):
    """Return bounded matches and whether the match count is truncated."""
    values = pattern_bytes(pattern)
    anchor = next(i for i, x in enumerate(values) if x is not None)
    fixed = bytes([values[anchor]])
    result, position = [], anchor
    while True:
        found = data.find(fixed, position)
        if found < 0:
            return result, False
        position = found + 1
        start = found - anchor
        if start + len(values) <= len(data) and all(
                x is None or data[start + i] == x for i, x in enumerate(values)):
            if len(result) == limit:
                return result, True
            result.append(start)


class MappedImage:
    """A bounded snapshot using memory RVAs, never file offsets or reference RVAs."""

    def __init__(self, read, base, snapshot_size):
        self.base = base
        if not 0 < snapshot_size <= MAX_IMAGE or not 0 < base < 2**32:
            raise ValueError('Expected bounded x86 module')
        dos = read(base, 64)
        if dos[:2] != b'MZ':
            raise ValueError('Missing DOS header')
        pe = u32(dos, 60)
        if pe < 64 or pe > min(snapshot_size - 24, 1024 * 1024):
            raise ValueError('Invalid PE header offset')
        coff = read(base + pe, 24)
        if coff[:4] != b'PE\0\0' or struct.unpack_from('<H', coff, 4)[0] != 0x14c:
            raise ValueError('Expected PE32 i386 module')
        count = struct.unpack_from('<H', coff, 6)[0]
        optional_size = struct.unpack_from('<H', coff, 20)[0]
        if not 1 <= count <= 96 or not 96 <= optional_size <= 4096:
            raise ValueError('Invalid PE section table')
        table_size = optional_size + count * 40
        if pe + 24 + table_size > snapshot_size:
            raise ValueError('Section table outside module')
        header = read(base + pe + 24, table_size)
        if struct.unpack_from('<H', header)[0] != 0x10b:
            raise ValueError('Expected PE32 optional header')
        self.size = u32(header, 56)
        if self.size != snapshot_size or base + self.size > 2**32:
            raise ValueError('Inconsistent module size')
        self.timestamp = u32(coff, 8)
        self.sections, self.read_errors = [], []
        budget = 0
        for i in range(count):
            entry = header[optional_size + i * 40:optional_size + (i + 1) * 40]
            name = entry[:8].split(b'\0')[0].decode('ascii', errors='replace')
            size, rva, raw_size = struct.unpack_from('<III', entry, 8)
            size = size or raw_size
            flags = u32(entry, 36)
            if not size or rva + size > self.size or rva < pe + 24 + table_size:
                raise ValueError('Invalid mapped section bounds')
            if any(rva < s['rva'] + s['size'] and s['rva'] < rva + size for s in self.sections):
                raise ValueError('Overlapping mapped sections')
            section = {'name': name, 'rva': rva, 'size': size, 'flags': flags, 'data': None}
            self.sections.append(section)
            # Executable code and the ordinary MSVC RTTI data sections suffice.
            if flags & READ and (flags & EXECUTE or name in ('.rdata', '.data')):
                budget += size
                if size > MAX_SECTION or budget > MAX_IMAGE:
                    raise ValueError('Module snapshot budget exceeded')
                try:
                    section['data'] = read(base + rva, size)
                    if len(section['data']) != size:
                        raise OSError('Partial mapped section read')
                except OSError as error:
                    section['data'] = None
                    self.read_errors.append({'section': name, 'error': str(error)})

    def data_at(self, rva, size):
        for section in self.sections:
            offset = rva - section['rva']
            if section['data'] is not None and 0 <= offset <= section['size'] - size:
                return section['data'][offset:offset + size]
        return None

    def executable(self, rva):
        return any(s['flags'] & EXECUTE and s['data'] is not None and
                   s['rva'] <= rva < s['rva'] + s['size'] for s in self.sections)

    def code_window(self, rva, before=32, after=128):
        for section in self.sections:
            if section['data'] is not None and section['flags'] & EXECUTE and \
                    section['rva'] <= rva < section['rva'] + section['size']:
                start = max(section['rva'], rva - before)
                end = min(section['rva'] + section['size'], rva + after)
                return {'window_rva': start, 'target_offset': rva - start,
                        'bytes': self.data_at(start, end - start).hex()}
        return None

    def pattern(self, pattern):
        found, truncated = [], False
        unavailable = False
        for section in self.sections:
            if not section['flags'] & EXECUTE:
                continue
            if section['data'] is None:
                unavailable = True
                continue
            offsets, extra = matches(section['data'], pattern)
            found.extend(section['rva'] + n for n in offsets)
            truncated |= extra
        return {'result': 'incomplete' if unavailable else
                'ambiguous' if len(found) > 1 or truncated else
                'unique_candidate' if found else 'absent',
                'match_count': len(found), 'count_truncated': truncated,
                'match_rvas': found[:32], 'code_windows': [self.code_window(rva) for rva in found[:32]],
                'hook_install_allowed': False}

    def occurrences(self, value):
        for section in self.sections:
            if section['data'] is None or section['flags'] & EXECUTE:
                continue
            position = 0
            while True:
                position = section['data'].find(value, position)
                if position < 0:
                    break
                yield section['rva'] + position
                position += 1

    def rtti(self, name, slots):
        result, truncated = [], False
        # MSVC x86 TypeDescriptor: two pointers followed by decorated name.
        for name_rva in self.occurrences(b'.?AV' + name.encode('ascii') + b'@@\0'):
            td = name_rva - 8
            if td % 4 or self.data_at(td, 8) is None:
                continue
            for type_pointer in self.occurrences(struct.pack('<I', self.base + td)):
                col = type_pointer - 12
                raw = self.data_at(col, 20)
                if col % 4 or raw is None:
                    continue
                signature, offset, cd_offset, _, hierarchy = struct.unpack('<5I', raw)
                chd = self.data_at(hierarchy - self.base, 16)
                if signature or offset > 1024 * 1024 or cd_offset > 1024 * 1024 or chd is None:
                    continue
                chd_signature, _, bases, base_array = struct.unpack('<4I', chd)
                if chd_signature or not 1 <= bases <= 4096 or self.data_at(base_array - self.base, bases * 4) is None:
                    continue
                for locator in self.occurrences(struct.pack('<I', self.base + col)):
                    table = locator + 4
                    first = self.data_at(table, 4)
                    if locator % 4 or first is None or not self.executable(u32(first) - self.base):
                        continue
                    if len(result) == 32:
                        return {'result': 'candidates', 'candidates': result, 'truncated': True,
                                'selected_game_slot': None, 'interface_binding_verified': False}
                    methods = {}
                    for slot in slots:
                        pointer = self.data_at(table + slot * 4, 4)
                        target = u32(pointer) - self.base if pointer else -1
                        valid = self.executable(target)
                        code = self.data_at(target, 32) if valid else None
                        methods[str(slot)] = {'target_rva': target if valid else None,
                                              'in_module_executable': valid,
                                              'first_32_bytes': code.hex() if code else None,
                                              'code_window': self.code_window(target, before=0) if valid else None,
                                              'semantics_verified': False}
                    result.append({'vtable_rva': table, 'locator_rva': col,
                                   'type_descriptor_rva': td, 'object_offset': offset,
                                   'candidate_slots': methods})
        return {'result': 'candidates' if result else 'unavailable',
                'candidates': result, 'truncated': truncated,
                'selected_game_slot': None, 'interface_binding_verified': False}

    def interface_registry(self):
        """Collect SDK InterfaceReg layout candidates without calling factories.

        Source's x86 entry is {factory, name, next}. Even matching this layout
        and a simple getter body does not validate a live SDK/game ABI.
        """
        result = []
        for section in self.sections:
            if section['data'] is None or section['flags'] & EXECUTE:
                continue
            for match in re.finditer(rb'(?:VMaterialSystem|VClient|VEngineClient|VEngineRenderView|ShaderApi)[0-9]{3}\0', section['data']):
                name_rva = section['rva'] + match.start()
                for pointer in self.occurrences(struct.pack('<I', self.base + name_rva)):
                    entry = pointer - 4
                    raw = self.data_at(entry, 12)
                    if entry % 4 or raw is None:
                        continue
                    factory, _, next_entry = struct.unpack('<3I', raw)
                    if not self.executable(factory - self.base):
                        continue
                    if next_entry and self.data_at(next_entry - self.base, 12) is None:
                        continue
                    code = self.data_at(factory - self.base, 32)
                    object_address = None
                    getter_shape = 'unresolved'
                    # Only two complete, side-effect-free x86 return shapes.
                    # Read their referenced value; never execute even these.
                    if code and code[5:6] == b'\xc3':
                        if code[0] == 0xb8:  # mov eax, imm32; ret
                            getter_shape = 'mov_eax_immediate_ret'
                            object_address = u32(code, 1)
                        elif code[0] == 0xa1:  # mov eax, [imm32]; ret
                            getter_shape = 'mov_eax_absolute_pointer_ret'
                            value = self.data_at(u32(code, 1) - self.base, 4)
                            object_address = u32(value) if value else None
                    table = self.data_at(object_address - self.base, 4) if object_address else None
                    table_rva = u32(table) - self.base if table else -1
                    first = self.data_at(table_rva, 4)
                    valid = first is not None and self.executable(u32(first) - self.base)
                    methods = {}
                    if valid and match.group().startswith(b'VMaterialSystem'):
                        for slot in (95, 96):
                            value = self.data_at(table_rva + slot * 4, 4)
                            target = u32(value) - self.base if value else -1
                            function = self.data_at(target, 32) if self.executable(target) else None
                            methods[str(slot)] = {'target_rva': target if function else None,
                                                  'first_32_bytes': function.hex() if function else None,
                                                  'code_window': self.code_window(target, before=0) if function else None,
                                                  'semantics_verified': False}
                    result.append({'name': match.group()[:-1].decode('ascii'),
                                   'entry_rva': entry, 'factory_rva': factory - self.base,
                                   'factory_first_32_bytes': code.hex() if code else None,
                                   'factory_code_window': self.code_window(factory - self.base, before=0),
                                   'getter_shape': getter_shape,
                                   'object_rva': object_address - self.base if valid else None,
                                   'vtable_rva': table_rva if valid else None,
                                   'candidate_slots': methods,
                                   'interface_binding_verified': False})
                    if len(result) == 32:
                        return {'result': 'candidates', 'candidates': result, 'truncated': True}
        return {'result': 'candidates' if result else 'unavailable',
                'candidates': result, 'truncated': False}

    def evidence(self, hooks, classes):
        return {'machine': 'i386', 'mapped_size': self.size, 'timestamp': self.timestamp,
                'base_address': self.base, 'read_errors': self.read_errors,
                'sections': [{k: v for k, v in s.items() if k != 'data'} |
                             {'mapped_sha256': hashlib.sha256(s['data']).hexdigest()
                              if s['data'] is not None else None} for s in self.sections],
                'hook_candidates': [{'symbol': h['symbol'], **self.pattern(h['pattern'])} for h in hooks],
                'rtti': {name: self.rtti(name, slots) for name, slots in classes.items()},
                'interface_registry': self.interface_registry(),
                'material_system_registry': self.interface_registry() if classes else {'result': 'not_requested'}}


def global_evidence(process, images, image, reference):
    """Read private global pointer candidates, never call their vtable methods."""
    result = {'symbol': reference['symbol'], **image.pattern(reference['pattern']),
              'interface_binding_verified': False, 'candidate_slots': {}}
    if result['result'] != 'unique_candidate':
        return result
    try:
        operand = image.data_at(result['match_rvas'][0] + reference['operand_offset'], 4)
        if operand is None:
            raise ValueError('Global pointer operand outside snapshot')
        storage = u32(operand)
        # The reference instruction names a pointer inside its own module.
        value = image.data_at(storage - image.base, 4)
        if value is None:
            raise ValueError('Global pointer storage outside module snapshot')
        address = u32(value)
        if not 0 < address < 2**32 - 4:
            raise ValueError('Null/invalid private global object')
        table = u32(process.read(address, 4))
        result.update(storage_rva=storage - image.base, object_address=address, vtable_address=table)
        owner = next(((name, candidate) for name, candidate in images.items()
                      if candidate.data_at(table - candidate.base, 4) is not None), None)
        if owner is None:
            result['vtable_result'] = 'outside_collected_modules'
            return result
        name, candidate = owner
        result.update(vtable_module=name, vtable_rva=table - candidate.base, vtable_result='candidate')
        for slot in reference['candidate_slots']:
            raw = candidate.data_at(table - candidate.base + 4 * slot, 4)
            target = u32(raw) if raw else 0
            method_owner = next(((n, m) for n, m in images.items() if m.executable(target - m.base)), None)
            method = {'target_address': target or None, 'semantics_verified': False}
            if method_owner:
                target_name, target_image = method_owner
                method.update(module=target_name, target_rva=target - target_image.base,
                              code_window=target_image.code_window(target - target_image.base, before=0))
            result['candidate_slots'][str(slot)] = method
    except (OSError, ValueError, struct.error) as error:
        result['error'] = str(error)
    return result


class WindowsProcess:
    """Only QUERY_INFORMATION/VM_READ; no remote thread or write access."""

    def __init__(self, pid):
        if os.name != 'nt':
            raise OSError('Loaded-module collection requires Windows')
        from ctypes import wintypes as w
        self.w = w
        self.api = ctypes.WinDLL('kernel32', use_last_error=True)
        signatures = {
            'OpenProcess': (w.HANDLE, [w.DWORD, w.BOOL, w.DWORD]),
            'CloseHandle': (w.BOOL, [w.HANDLE]),
            'ReadProcessMemory': (w.BOOL, [w.HANDLE, ctypes.c_void_p, ctypes.c_void_p,
                                         ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]),
            'CreateToolhelp32Snapshot': (w.HANDLE, [w.DWORD, w.DWORD]),
            'GetProcessTimes': (w.BOOL, [w.HANDLE] + [ctypes.POINTER(w.FILETIME)] * 4),
            'GetExitCodeProcess': (w.BOOL, [w.HANDLE, ctypes.POINTER(w.DWORD)]),
        }
        for name, (restype, argtypes) in signatures.items():
            function = getattr(self.api, name)
            function.restype, function.argtypes = restype, argtypes
        self.pid = pid
        self.handle = self.api.OpenProcess(0x0400 | 0x0010, False, pid)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.api.CloseHandle(self.handle)

    def identity(self):
        times = [self.w.FILETIME() for _ in range(4)]
        exit_code = self.w.DWORD()
        if not self.api.GetProcessTimes(self.handle, *[ctypes.byref(x) for x in times]):
            raise ctypes.WinError(ctypes.get_last_error())
        if not self.api.GetExitCodeProcess(self.handle, ctypes.byref(exit_code)):
            raise ctypes.WinError(ctypes.get_last_error())
        return {'pid': self.pid, 'creation_filetime': times[0].dwLowDateTime |
                times[0].dwHighDateTime << 32, 'alive': exit_code.value == 259}

    def read(self, address, size):
        if not 0 < size <= MAX_SECTION:
            raise ValueError('Invalid memory read size')
        data = ctypes.create_string_buffer(size)
        copied = ctypes.c_size_t()
        if not self.api.ReadProcessMemory(self.handle, address, data, size, ctypes.byref(copied)) or copied.value != size:
            raise OSError(f'ReadProcessMemory at {address:#x}, size {size}: error {ctypes.get_last_error()}')
        return data.raw

    def modules(self):
        w = self.w

        class Entry(ctypes.Structure):
            _fields_ = [('dwSize', w.DWORD), ('th32ModuleID', w.DWORD),
                        ('th32ProcessID', w.DWORD), ('GlblcntUsage', w.DWORD),
                        ('ProccntUsage', w.DWORD), ('modBaseAddr', ctypes.c_void_p),
                        ('modBaseSize', w.DWORD), ('hModule', w.HMODULE),
                        ('szModule', w.WCHAR * 256), ('szExePath', w.WCHAR * 260)]

        for name in ('Module32FirstW', 'Module32NextW'):
            function = getattr(self.api, name)
            function.restype, function.argtypes = w.BOOL, [w.HANDLE, ctypes.POINTER(Entry)]
        snapshot = None
        # ERROR_BAD_LENGTH is documented for racing loader snapshots.
        for _ in range(4):
            # Some WOW64 snapshots omit the EXE with SNAPMODULE32 alone.
            # Retain both lists and coalesce only identical module identities.
            flags = 0x18 if ctypes.sizeof(ctypes.c_void_p) == 8 else 0x08
            snapshot = self.api.CreateToolhelp32Snapshot(flags, self.pid)
            if snapshot != ctypes.c_void_p(-1).value:
                break
            if ctypes.get_last_error() != 24:
                raise ctypes.WinError(ctypes.get_last_error())
        if snapshot == ctypes.c_void_p(-1).value:
            raise OSError('Module snapshot changed during all four attempts')
        try:
            entry = Entry(); entry.dwSize = ctypes.sizeof(entry)
            ok = self.api.Module32FirstW(snapshot, ctypes.byref(entry))
            result = []
            while ok:
                result.append({'name': entry.szModule.lower(), 'path': entry.szExePath,
                               'base': entry.modBaseAddr, 'size': entry.modBaseSize})
                ok = self.api.Module32NextW(snapshot, ctypes.byref(entry))
            if ctypes.get_last_error() != 18:  # ERROR_NO_MORE_FILES
                raise ctypes.WinError(ctypes.get_last_error())
            return unique_modules(result)
        finally:
            self.api.CloseHandle(snapshot)


def file_identity(path):
    path = Path(path)
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise OSError('Module file changed while hashing')
    return {'size': after.st_size, 'sha256': digest.hexdigest()}



def convar_candidates(process, images):
    """Read SDK-layout candidates; never equate a data layout with a current ABI."""
    names=('mat_queue_mode','r_threaded_particles','r_threaded_renderables','r_threadeddetailprops',
           'cl_threaded_bone_setup','r_threaded_client_shadow_manager')
    result=[]
    def string(address):
        if not address:return None
        try:
            data=process.read(address,64)
            if b'\0' not in data:return None
            return data.split(b'\0',1)[0].decode('ascii')
        except (OSError,UnicodeDecodeError):return None
    def executable(address):return any(image.executable(address-image.base) for image in images.values())
    for module,image in images.items():
        for name in names:
            needles=[]
            for section in image.sections:
                data=section['data']
                if data is None:continue
                position=0
                while len(needles)<8:
                    at=data.find(name.encode()+b'\0',position)
                    if at<0:break
                    needles.append(image.base+section['rva']+at);position=at+len(name)+1
            for address in needles:
                for section in image.sections:
                    data=section['data']
                    if section['name']!='.data' or data is None:continue
                    position=0;references=0
                    while references<16:
                        at=data.find(struct.pack('<I',address),position)
                        if at<0:break
                        position=at+4;references+=1;obj=image.base+section['rva']+at-12
                        if obj%4:continue
                        try:
                            raw=process.read(obj,64);table=u32(raw);root=u32(raw,28)
                            if u32(raw,12)!=address or raw[8]!=1 or not root:continue
                            if not executable(u32(process.read(table,4))):continue
                            parent=process.read(root,64)
                            if u32(parent,28)!=root or u32(parent)!=table:continue
                            value={'module':module,'name':name,'object_rva':obj-image.base,'root_address':root,
                                   'sdk_candidate_int':struct.unpack_from('<i',parent,48)[0],
                                   'sdk_candidate_float':struct.unpack_from('<f',parent,44)[0],
                                   'sdk_candidate_string':string(u32(parent,36)),
                                   'sdk_candidate_default':string(u32(parent,32)),
                                   'root_object_hex':parent.hex(),'current_abi_verified':False,'cvar_written':False}
                            # JSON must not acquire non-standard NaN/Infinity values.
                            import math
                            if not math.isfinite(value['sdk_candidate_float']):value['sdk_candidate_float']=None
                            result.append(value)
                        except (OSError,ValueError,struct.error):continue
    return {'scope':'read_only_sdk_layout_candidates_not_verified_cvar_or_parallel_execution',
            'sdk_offsets':{'name':12,'parent':28,'default':32,'string':36,'float':44,'int':48},
            'candidates':result,'source_parallel_preparation':'unrun','cvar_writes':False}

def collect(pid, audit):
    report = {'schema': 1, 'scope': 'read_only_game_binding_candidates', 'execution': 'incomplete',
              'reference_mod_commit': json.loads((ROOT / 'integration/rt/baseline.json').read_text())['compat_commit'],
              'reference_audit_sha256': hashlib.sha256(json.dumps(audit, sort_keys=True).encode()).hexdigest(),
              'collector_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'sdk_candidate_manifest_sha256': hashlib.sha256(
                  (ROOT / 'research/rt-source-queue-sdk.json').read_bytes()).hexdigest(),
              'hook_install_allowed': False, 'game_queue_execution': 'unrun',
              'b580_rt': 'unrun', 'snapshot_atomic': False, 'modules': []}
    try:
        with WindowsProcess(pid) as process:
            report['process'] = process.identity()
            if not report['process']['alive']:
                raise OSError('Target process has exited')
            before = process.modules()
            renderer = select_renderer(before)
            report['renderer_selection'] = renderer
            bindings = dict(MODULES)
            if renderer['name']:
                bindings['RENDERER_MOD'] = renderer['name']
            images = {}
            required = set(bindings.values()) | {'materialsystem.dll'}
            stable = True
            for name in sorted(required):
                candidates = [m for m in before if m['name'] == name]
                item = {'name': name, 'result': 'unavailable'}
                report['modules'].append(item)
                if name == bindings['RENDERER_MOD']:
                    item['reference_module'] = MODULES['RENDERER_MOD']
                    item['reference_module_differs'] = name != MODULES['RENDERER_MOD']
                    if renderer['result'] != 'unique_candidate':
                        item['error'] = 'Renderer missing or ambiguous'; stable = False; continue
                if len(candidates) != 1:
                    item['error'] = 'Module missing or ambiguous'; stable = False; continue
                module = candidates[0]
                item.update(path=module['path'], base_address=module['base'],
                            snapshot_alias_count=module['snapshot_alias_count'])
                try:
                    item['file'] = file_identity(module['path'])
                    hooks = [h for h in audit['hook_references'] if bindings[h['module']] == name]
                    classes = CLASSES if name == 'materialsystem.dll' else {}
                    image = MappedImage(process.read, module['base'], module['size'])
                    images[name] = image
                    item.update(image.evidence(hooks, classes))
                    item['result'] = 'incomplete' if image.read_errors else 'snapshot_collected'
                    stable &= not image.read_errors
                except (OSError, ValueError, struct.error) as error:
                    item['error'] = str(error); stable = False
            optional=[m for m in before if m['name']=='vstdlib.dll']
            if len(optional)==1:
                try:
                    module=optional[0];images['vstdlib.dll']=MappedImage(process.read,module['base'],module['size'])
                    report['optional_cvar_module']={'name':'vstdlib.dll','file':file_identity(module['path'])}
                except (OSError,ValueError,struct.error) as error:
                    report['optional_cvar_module']={'error':str(error)}
            report['thread_cvar_candidates']=convar_candidates(process,images)
            report['private_global_candidates'] = []
            for reference in audit.get('global_references', []):
                name = bindings[reference['module']]
                if name in images:
                    report['private_global_candidates'].append(global_evidence(process, images, images[name], reference))
            after = process.modules()
            report['renderer_selection_stable'] = select_renderer(after) == renderer
            stable &= report['renderer_selection_stable']
            for name in required:
                identity = lambda entries: [(x['base'], x['size'], x['path']) for x in entries if x['name'] == name]
                if identity(before) != identity(after):
                    stable = False
            report['module_list_stable'] = all(
                [(x['base'], x['size'], x['path']) for x in before if x['name'] == name] ==
                [(x['base'], x['size'], x['path']) for x in after if x['name'] == name]
                for name in required)
            report['process_after'] = process.identity()
            if not report['process_after']['alive']:
                stable = False
            report['execution'] = 'snapshot_collected' if stable else 'incomplete'
    except (OSError, ValueError) as error:
        report['error'] = str(error)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pid', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True, help='New output directory inside the suite session')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    audit = json.loads((ROOT / 'research/rt-source-audit.json').read_text())
    result = collect(args.pid, audit)
    (args.output / 'game-binding.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'execution': result['execution'], 'hook_install_allowed': False}))
    raise SystemExit(0 if result['execution'] == 'snapshot_collected' else 1)
