Development collector checks only. No game hooks, RT runtime or user test package A.
